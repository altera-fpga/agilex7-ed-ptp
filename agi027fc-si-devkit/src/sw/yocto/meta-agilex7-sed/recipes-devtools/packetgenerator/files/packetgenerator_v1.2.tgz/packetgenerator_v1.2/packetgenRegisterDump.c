/*********************************************************************************
 * **                                                                           **
 * ** ALTERA CONFIDENTIAL                                                       **
 * **                                                                           **
 * ** Copyright 2024 Altera/ALTERA Corporation All Rights Reserved.             **
 * **                                                                           **
 * ** The source code contained or described herein and all documents related   **
 * ** to the source code ("Material") are owned by Altera Corporation or its    **
 * ** suppliers or licensors.  Title to the Material remains with Altera        **
 * ** Corporation or its suppliers and licensors.  The Material contains trade  **
 * ** secrets and proprietary and confidential information of Altera or its     **
 * ** suppliers and licensors.  The Material is protected by worldwide          **
 * ** copyright and trade secret laws and treaty provisions.  No part of the    **
 * ** Material may be used, copied, reproduced, modified, published, uploaded,  **
 * ** posted, transmitted, distributed, or disclosed in any way without Altera's**
 * ** prior express written permission.                                         **
 * **                                                                           **
 * ** No license under any patent, copyright, trade secret or other             **
 * ** intelectual property right is granted to or conferred upon you by         **
 * ** disclosure or delivery of the Materials, either expressly, by             **
 * ** implication, inducement, estoppel or otherwise.  Any license under such   **
 * ** intelectual property rights must be express and approved by Altera in     **
 * ** writing.                                                                  **
 * **                                                                           **
 * ** Application - Packet Generator v1.0                                       **
 * ** Author - Krishna Kumar S R                                                **
 * ******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "packetgenRegisterMap.h"

/**
 * @brief Function to dump the PktGen configuration control.
 * This function prints out the current configuration control of PktGen.
 * It provides information about the current state of PktGen and its settings.
 */
void dumpPktGenConfigControl(pktGenConfigControl_t *config)
{
	printf("Config Control: 0x%x\n", config->value);
	printf("\tTx traffic: %s\n", ((PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_GET(config->genconfig.tx_traffic) == PKTGEN_CONFIG_CONTROL_TX_TRAFFIC_ENABLE)?"Enabled":"Disabled"));
	if (PKTGEN_CONFIG_CONTROL_ONE_SHOT_MODE_GET(config->genconfig.one_shot_mode) == PKTGEN_CONFIG_CONTROL_CONTINUOUS_MODE_ENABLE) {
		printf("\tPacket Generation Mode: Continuous \n");
	} else {
		printf("\tPacket Generation Mode: One Shot \n");
	}
	printf("\tSoft Reset: %s\n", ((PKTGEN_CONFIG_CONTROL_SOFT_RESET_GET(config->genconfig.pktgen_soft_reset) == PKTGEN_CONFIG_CONTROL_SOFT_RESET_ENABLE)?"Enabled":"Disabled"));
	printf("\tDynamic Mode: %s\n", ((PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_GET(config->genconfig.dynamic_mode_pktgen) == PKTGEN_CONFIG_CONTROL_DYNAMIC_MODE_ENABLE)?"Enabled":"Disabled"));
	printf("\tPkt Checker: %s\n", ((PKTGEN_CONFIG_CONTROL_PKT_CHECKER_GET(config->genconfig.pkt_checker) == PKTGEN_CONFIG_CONTROL_PKT_CHECKER_ENABLE)?"Enabled":"Disabled"));
	printf("\tCounter Snapshot Status: %s\n", ((PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_GET(config->genconfig.cntr_snapshot) == PKTGEN_CONFIG_CONTROL_CNTR_SNAPSHOT_ENABLE)?"Enabled":"Disabled"));
	printf("\tCounter Clear Status: %s\n", ((PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_GET(config->genconfig.cntr_clear) == PKTGEN_CONFIG_CONTROL_CNTR_CLEAR_ENABLE)?"Enabled":"Disabled"));
	printf("\tInternal Counter Clear Status: %s\n", ((PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_GET(config->genconfig.cntr_internal_clear) == PKTGEN_CONFIG_CONTROL_CNTR_INTERNAL_CLEAR_ENABLE)?"Enabled":"Disabled"));
	printf("\tFixed Gap: %s\n", ((PKTGEN_CONFIG_CONTROL_FIXED_GAP_GET(config->genconfig.fixed_gap) == PKTGEN_CONFIG_CONTROL_FIXED_GAP_ENABLE)?"Enabled":"Disabled"));

	if (PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_GET(config->genconfig.pkt_length_mode) == PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_FIXED_LENGTH) {
		printf("\tPacket Length Mode: %s\n","Fixed");
	} else if (PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_GET(config->genconfig.pkt_length_mode) == PKTGEN_CONFIG_CONTROL_PKT_LENGTH_MODE_INCR_LENGTH) {
		printf("\tPacket Length Mode: %s\n","Incremental pattern");
	} else {
		printf("\tPacket Length Mode: %s\n","Error");
	}

	printf("\tNumber of Idle Cycles: %d\n", PKTGEN_CONFIG_CONTROL_NUM_IDLE_CYCLES_GET(config->genconfig.num_idle_cycles));
}
/**
 * @brief Configure the packet size for the PktGen module.
 *
 * This function is used to configure the packet size for the PktGen module.
 * It takes no arguments and returns void.
 * The packet size determines the size of the packets generated by the PktGen module.
 * This configuration affects the size of the packets sent by the PktGen module.
 * The default packet size is set to a specific value, but it can be modified using this function.
 * The new packet size will be applied to all subsequent packets generated by the PktGen module.
 */
void dumpPktGenPktSizeConfig(pktGenPktSizeConfig_t *config, uint32 num_words)
{
	if (num_words < 1 || num_words > 4)
		num_words = 1;
	printf("Packet Size Config Control: 0x%x\n", config->value);
	printf("\tTx Packet Size: %d Tx Max Packet Size: %d\n", PKTGEN_PKTSIZE_CONFIG_TX_PACKET_SIZE_GET(config->sizecfg.tx_packet_size) * num_words, 
			PKTGEN_PKTSIZE_CONFIG_TX_PACKET_SIZE_GET(config->sizecfg.tx_packet_size_max)*num_words);
	return;
}
/**
 * @brief Dump the status of the PktGen module.
 *
 * This function prints the current status of the PktGen module, including
 * information about the packets being generated, the transmission rate,
 * and any errors or warnings that have occurred.
 *
 * @return void
 */
void dumpPktGenStatus(pktGenStatus_t *status)
{
	printf("Packet Generator Status: 0x%x\n", status->value);
	printf("\tSADB configuration status: %s\n", ((PKTGEN_SYSTEM_STATUS_SADB_CONFIG_GET(status->genstatus.sadb_config))?"Complete":"Incomplete"));
	printf("\tSystem Reset Sequence status: %s\n", ((PKTGEN_SYSTEM_STATUS_SYSTEM_RESET_SEQUENCE_GET(status->genstatus.sysreset))?"Complete":"Incomplete"));
	printf("\tHSSI SS tx_lanes_stable status: %s\n", ((PKTGEN_SYSTEM_STATUS_TX_LANE_STATUS_GET(status->genstatus.tx_lane))?"Asserted":"Deasserted"));
	printf("\tHSSI SS tx_pll_locked status: %s\n", ((PKTGEN_SYSTEM_STATUS_TX_PLL_LOCK_GET(status->genstatus.tx_pll))?"Asserted":"Deasserted"));
	printf("\tHSSI SS rx_pcs status: %s\n", ((PKTGEN_SYSTEM_STATUS_RX_PCS_READY_GET(status->genstatus.rx_pcs))?"Asserted":"Deasserted"));
	return;

}

/**
 * @brief Dump the status of the PktGenChecker.
 *
 * This function is used to print the current status of the PktGenChecker.
 * It provides information about the internal state of the PktGenChecker,
 * such as the number of packets processed, the number of errors detected,
 * and any other relevant information.
 *
 * @return void
 */
void dumpPktGenCheckerStatus(pktGenCheckerStatus_t *status)
{
	printf("Packet Checker Status: 0x%x\n", *((uint32*)status));
	printf("\tData Mismatch status: %s\n", ((PKTGEN_CHECKER_STATUS_DATA_MISMATCH_GET(status->data_mismatch))?"Seen":"Not seen"));
}

/**
 * @brief Dump the number of words of the Packetgenerator
 *
 * This function is used to print the number of words used for data by the PktGen
 *
 * @return void
 */
#define NUM_WORDS_DEFAULT 1
void dumpPktGenNumWords(uint32 *num_words)
{
	if (*num_words < 1 || *num_words > 4)
		printf("%d\n", NUM_WORDS_DEFAULT);
	else
		printf("%d\n", *((uint32*)num_words));
}
/**
 * @brief Dump the packet generator statistics.
 *
 * This function is used to dump the statistics of the packet generator.
 * It takes a pointer to a pktGenStatistics_t structure as a parameter.
 * The function does not return a value.
 *
 * @param stats A pointer to the pktGenStatistics_t structure to be dumped.
 */
void dumpPktGenStatistics(pktGenStatistics_t *stats)
{
	uint64 temp = 0;
	temp |= stats->high;
	temp = temp << 32;
	sleep(0);
	temp |= stats->low;
	printf("%lu\n", temp);
	return;
}
/**
 * @brief Dumps the PktGen bandwidth.
 *
 * This function is responsible for dumping the PktGen bandwidth.
 * It retrieves the current bandwidth information and prints it to the console.
 * 
 * @param stats A pointer to the pktGenStatistics_t structure to be dumped.
 * 
 * @return None
 */
#define NUM_BITS_BUS	64
void dumpPktGenBandwidth(pktGenStatistics_t *stats, uint32 num_words)
{
	uint64 temp = 0;
	temp |= stats->high;
	temp = temp << 32;
	sleep(0);
	temp |= stats->low;
	if (num_words < 1 || num_words > 4)
		num_words = 1;
	printf("%ld bps\n", (temp*num_words*NUM_BITS_BUS));
	return;
}

/**
 * @brief Prints the MAC address.
 *
 * This function prints the MAC address of the device.
 * @param macAddr MAC address to be printed
 */
void print_mac_address(const mac_address *macAddr) {
	printf("%02X:%02X:%02X:%02X:%02X:%02X\n",
			macAddr->mac.byte_0,
			macAddr->mac.byte_1,
			macAddr->mac.byte_2,
			macAddr->mac.byte_3,
			macAddr->mac.byte_4,
			macAddr->mac.byte_5);
}
/**
 * @brief Dumps the PktGen structure.
 *
 * This function is used to dump the contents of the PktGen structure.
 * It provides a detailed view of the internal state of the PktGen structure,
 * including all the variables and their current values.
 *
 * @param pktGen The PktGen structure to be dumped.
 */
void dumpPktGenStructure(packetgen_t *pktgen)
{
	dumpPktGenConfigControl(&(pktgen->config));
	printf("Destination Mac Address: "); 
	print_mac_address(&pktgen->dynamic_dest_mac_addr);
	printf("Source Mac Address: "); 
	print_mac_address(&pktgen->dynamic_src_mac_addr);
	printf("Number of Packets: %u\n", pktgen->num_packets);
	dumpPktGenPktSizeConfig(&(pktgen->pkt_size_config), pktgen->num_words);
	dumpPktGenStatus(&pktgen->misc_status);
	dumpPktGenCheckerStatus(&pktgen->checker_status);
	printf("TX Start of Packet Count: "); dumpPktGenStatistics(&pktgen->tx_sop_cnt);
	printf("TX End of Packet Count: "); dumpPktGenStatistics(&pktgen->tx_eop_cnt);
	printf("TX Error Packet Count: "); dumpPktGenStatistics(&pktgen->tx_err_cnt);
	printf("RX Start of Packet Count: "); dumpPktGenStatistics(&pktgen->rx_sop_cnt);
	printf("RX End of Packet Count: "); dumpPktGenStatistics(&pktgen->rx_eop_cnt);
	printf("RX Error Packet Count: "); dumpPktGenStatistics(&pktgen->rx_err_cnt);
	printf("Pkt Checker Live Counter: %u\n", pktgen->checker_stats);
	printf("PKT TX Byte Count: "); dumpPktGenStatistics(&pktgen->pktcli_tx_byte_cnt);
	printf("PKT RX Byte Count: "); dumpPktGenStatistics(&pktgen->pktcli_rx_byte_cnt);
	printf("PKT TX Num Ticks Count: "); dumpPktGenStatistics(&pktgen->pktcli_tx_ticks_cnt);
	printf("PKT RX Num Ticks Count: "); dumpPktGenStatistics(&pktgen->pktcli_rx_ticks_cnt);
	printf("TX Bandwidth: "); dumpPktGenBandwidth(&pktgen->txBandwidth, pktgen->num_words);
	printf("RX Bandwidth: "); dumpPktGenBandwidth(&pktgen->rxBandwidth, pktgen->num_words);
	printf("Number of words: "); dumpPktGenNumWords(&pktgen->num_words);
	return;
}
