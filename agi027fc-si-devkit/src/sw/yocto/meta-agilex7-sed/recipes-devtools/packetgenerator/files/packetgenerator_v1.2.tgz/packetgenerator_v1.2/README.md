# PacketGenerator
Linux Application to configure the Packet Generator module integrated with Ethernet based System example designs

This application helps configure the packetgenerator IP which provides a test packet generator program in the FPGA.
The application helps configure the IP to generate test L2 packets which can be used to test the FPGA data pipeline
and test the line rate. It has multiple options that can help create variety of traffic patterns including different
destination and source MAC addresses, frame sizes and idle packet gap. Refer to the application help menu for all the
options. this application has been tested on the ARM based HPS of the Altera FPGA and is intended to be run only in 
that environment. Usgae of this application else where could be done at your own risk.

The applictaion is pretty easy to configure and make. If you have all the shell environment variables setup, 
please use autoconf utilities to make the package.

$ autoconf
$ ./configure
$ make all
$ make install

Usually, if you have the cross compilers setup and want to make the application only then use the specific compiler
to generate the application directly

Download toolchain from https://developer.arm.com/-/media/Files/downloads/gnu/11.3.rel1/binrel/arm-gnu-toolchain-11.3.rel1-x86_64-aarch64-none-linux-gnu.tar.xz
extract it,
 
$ export ARCH=arm64;
$ export CROSS_COMPILE=`pwd`/arm-gnu-toolchain-11.3.rel1-x86_64-aarch64-none-linux-gnu/bin/aarch64-none-linux-gnu-
$ cd ${working directory}
$ aarch64-none-linux-gnu-gcc *.c -o packetgenerator

Look out for the help menu ("$packetgenerator --help") to check for usage of the application
